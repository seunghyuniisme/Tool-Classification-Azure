# myapp/forms.py

from django import forms
from .models import ToolImage

class ToolImageForm(forms.ModelForm):
    class Meta:
        model = ToolImage
        fields = ['image']
