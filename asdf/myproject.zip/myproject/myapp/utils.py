# myapp/utils.py
import json

def load_product_info(json_file_path):
    with open(json_file_path, 'r', encoding='utf-8') as f:
        return json.load(f)
import requests

ENDPOINT = "https://30findbuneemlcv20240717-prediction.cognitiveservices.azure.com"
PREDICTION_KEY = "77fdcfb7028a4933b1b8efe9587a26ea"
PROJECT_ID = "f67342fc-9055-4960-b0df-ef9c57dd827f"
PUBLISH_ITERATION_NAME = "Hani_wind"

def classify_image(image_path):
    url = f"{ENDPOINT}/customvision/v3.0/Prediction/{PROJECT_ID}/classify/iterations/{PUBLISH_ITERATION_NAME}/image"
    headers = {
        "Prediction-Key": PREDICTION_KEY,
        "Content-Type": "application/octet-stream"
    }
    with open(image_path, 'rb') as image_data:
        response = requests.post(url, headers=headers, data=image_data)
    return response.json()
