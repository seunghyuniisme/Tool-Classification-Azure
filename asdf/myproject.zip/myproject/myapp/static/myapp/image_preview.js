function previewImage() {
    const fileInput = document.getElementById('image');
    const previewContainer = document.getElementById('imagePreview');
    previewContainer.innerHTML = ''; // Clear previous previews
    
    const file = fileInput.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            img.style.maxWidth = '80%'; // Adjust the max-width as needed
            img.style.maxHeight = 'auto'; // Adjust the max-height as needed
            img.style.marginTop = '10px'; // 이미지 위쪽 여백 조정
            previewContainer.appendChild(img);

             // 숨기기
             uploadText.classList.add('hidden');
             fileLabel.classList.add('hidden');
        }
        reader.readAsDataURL(file);
    }
}
