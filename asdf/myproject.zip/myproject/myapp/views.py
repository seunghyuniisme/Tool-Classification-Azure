from django.shortcuts import render, redirect
from django.core.files.storage import default_storage
from django.conf import settings
import os

# myproject/myapp/views.py

from django.shortcuts import render

# 추가된 import
from .forms import ToolImageForm

def main_page(request):
    return render(request, 'myapp/main.html')


def upload_image(request):
    if request.method == 'POST':
        # 이미지 업로드 처리 로직
        pass
    return render(request, 'myapp/image_upload.html')  # 템플릿 파일 경로



def image_upload_page(request):
    if request.method == 'POST':
        form = ToolImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()  # 이미지를 저장합니다.
            # 여기에서 추가적인 이미지 처리 로직을 추가할 수 있습니다.
            return redirect('image_upload_page')  # 업로드 후 리디렉션할 페이지
    else:
        form = ToolImageForm()

    return render(request, 'myapp/image_upload.html', {'form': form})



def success_page(request):
    return render(request, 'myapp/success.html')  # 업로드 성공 페이지